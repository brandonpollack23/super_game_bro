/* GameMan Board Support Header
	 Brandon Pollack
*/

#ifndef __GAMEMAN_BSP
#define __GAMEMAN_BSP

//comment out this line to remove debug prints
#define DEBUG_MSG_EN

#define DEBUG_UART &huart1

HAL_StatusTypeDef print_debug(uint8_t *pData, uint16_t Size, uint32_t Timeout);

#endif
